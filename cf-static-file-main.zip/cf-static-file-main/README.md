# cf-static-file
Static file deployment test for Cloud Foundry
